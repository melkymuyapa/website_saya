<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visi &amp; Misi - Entakamala</title>
    <script>
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            window.location.href = '/';
        }

        function logout() {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    </script>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f6f9;
            color: #1e293b;
            line-height: 1.6;
        }

        /* Header */
        .top-header {
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-inner {
            max-width: 1200px;
            margin: 0 auto;
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #0f172a;
        }

        .brand img {
            width: 42px;
            height: 42px;
            object-fit: contain;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-text strong {
            font-size: 1rem;
            letter-spacing: 0.5px;
            color: #0f172a;
        }

        .brand-text span {
            font-size: 0.75rem;
            color: #64748b;
        }

        .btn-logout {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            background: #ef4444;
            color: #ffffff;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .btn-logout:hover {
            background: #dc2626;
        }

        /* Konten Utama */
        .submenu-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 36px 24px;
        }

        .submenu-card {
            background: #ffffff;
            border-radius: 14px;
            padding: 36px;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.06);
            display: grid;
            grid-template-columns: 0.85fr 1.15fr;
            gap: 32px;
            align-items: center;
        }

        .submenu-media {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .submenu-photo {
            width: 100%;
            max-width: 280px;
            max-height: 280px;
            object-fit: contain;
            border-radius: 8px;
            display: block;
        }

        .badge {
            display: inline-block;
            background-color: #eff6ff;
            color: #2563eb;
            font-size: 0.8rem;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 12px;
        }

        .submenu-text h1 {
            font-size: 1.75rem;
            color: #0f172a;
            margin-bottom: 14px;
        }

        .submenu-text h2 {
            font-size: 1.05rem;
            color: #0f172a;
            margin-bottom: 6px;
        }

        .submenu-text p {
            color: #475569;
            font-size: 15px;
            margin-bottom: 16px;
        }

        .misi-list {
            color: #475569;
            font-size: 15px;
            padding-left: 20px;
            margin-bottom: 24px;
        }

        .misi-list li {
            margin-bottom: 6px;
        }

        .btn-back {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            background: #2563eb;
            color: #ffffff;
            font-size: 0.95rem;
            font-weight: 500;
            transition: background-color 0.2s;
        }

        .btn-back:hover {
            background: #1d4ed8;
        }

        @media (max-width: 768px) {
            .submenu-card {
                grid-template-columns: 1fr;
                padding: 24px;
            }
        }
    </style>
</head>
<body>

    <header class="top-header">
        <div class="header-inner">
            <a href="{{ url('/beranda') }}" class="brand">
                <img src="{{ asset('image/logo2.png') }}" alt="Logo Entakamala">
                <div class="brand-text">
                    <strong>ENTAKAMALA</strong>
                    <span>Digital &amp; Personal Web</span>
                </div>
            </a>

            <button type="button" class="btn-logout" onclick="logout()">Logout</button>
        </div>
    </header>

    <main class="submenu-container">
        <section class="submenu-card">
            <div class="submenu-media">
                <img src="{{ asset('image/logo2.png') }}" alt="Visi dan Misi Entakamala" class="submenu-photo">
            </div>

            <div class="submenu-text">
                <span class="badge">Tentang Kami</span>
                <h1>Visi &amp; Misi</h1>

                <h2>Visi</h2>
                <p>Menjadi ruang digital dan pengembangan web yang inovatif, terpercaya, serta memberikan solusi teknologi yang mudah diakses dan bermanfaat.</p>

                <h2>Misi</h2>
                <ul class="misi-list">
                    <li>Merancang antarmuka (UI/UX) yang bersih, modern, dan nyaman digunakan di berbagai perangkat.</li>
                    <li>Mengembangkan aplikasi dan website yang cepat, terstruktur, dan aman.</li>
                    <li>Terus belajar dan beradaptasi dengan perkembangan teknologi web terkini.</li>
                </ul>

                <a href="{{ url('/beranda') }}" class="btn-back">&larr; Kembali ke Beranda</a>
            </div>
        </section>
    </main>

</body>
</html>
