<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Entakamala - Entakamala</title>
    <script>
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            window.location.href = '/';
        }

        function logout() {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    </script>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f6f9;
            color: #1e293b;
            line-height: 1.7;
        }

        .top-header {
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
            padding: 12px 24px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #0f172a;
        }

        .brand img {
            width: 42px;
            height: 42px;
            object-fit: contain;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-text strong {
            font-size: 1rem;
            letter-spacing: 0.5px;
            color: #0f172a;
        }

        .brand-text span {
            font-size: 0.75rem;
            color: #64748b;
        }

        .btn-logout {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            background: #ef4444;
            color: #ffffff;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .btn-logout:hover {
            background: #dc2626;
        }

        .profile-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 36px 24px;
        }

        .profile-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 36px;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.05);
            display: grid;
            grid-template-columns: 0.85fr 1.15fr;
            gap: 32px;
            align-items: start;
        }

        .profile-media {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .profile-photo {
            width: 100%;
            max-width: 280px;
            max-height: 320px;
            object-fit: contain;
            border-radius: 8px;
            display: block;
        }

        .badge {
            display: inline-block;
            background-color: #eff6ff;
            color: #2563eb;
            font-size: 0.8rem;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 12px;
        }

        .profile-content h1 {
            font-size: 1.8rem;
            color: #0f172a;
            margin-bottom: 14px;
        }

        .profile-content p {
            color: #475569;
            font-size: 15.5px;
            margin-bottom: 14px;
        }

        .profile-content p:last-of-type {
            margin-bottom: 24px;
        }

        .btn-back {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            background: #2563eb;
            color: #ffffff;
            font-size: 0.95rem;
            font-weight: 500;
            transition: background-color 0.2s;
        }

        .btn-back:hover {
            background: #1d4ed8;
        }

        @media (max-width: 768px) {
            .profile-card {
                grid-template-columns: 1fr;
                padding: 24px;
            }
        }
    </style>
</head>
<body>

    <header class="top-header">
        <div class="header-inner">
            <a href="{{ url('/beranda') }}" class="brand">
                <img src="{{ asset('image/logo2.png') }}" alt="Logo Entakamala">
                <div class="brand-text">
                    <strong>ENTAKAMALA</strong>
                    <span>Digital &amp; Personal Web</span>
                </div>
            </a>

            <button type="button" class="btn-logout" onclick="logout()">Logout</button>
        </div>
    </header>

    <main class="profile-container">
        <section class="profile-card">
            <div class="profile-media">
                <img src="{{ asset('image/logo2.png') }}" alt="Foto Profil Entakamala" class="profile-photo">
            </div>

            <div class="profile-content">
                <span class="badge">Tentang Kami</span>
                <h1>Tentang Saya &amp; Entakamala</h1>

                <p>
                    Halo, perkenalkan saya Entakamala, seorang mahasiswa asal Papua yang sedang menempuh pendidikan di perguruan tinggi IT, yakni Universitas Bhinneka Nusantara di kota Malang. Jurusan yang saya pilih adalah Sistem Informasi, dan saat ini saya telah berada di semester 5 yang penuh tantangan, pembelajaran, serta proses menuju perjalanan magang.
                </p>

                <p>
                    Perjalanan hidup saya sejak lama dibentuk oleh dinamika perantauan dan keberanian beradaptasi. Sebelum menapaki bangku kuliah di Malang, saya telah mengalami kehidupan sebagai anak rantau selama kurang lebih 20 tahun di Timika dan Jayapura, dua daerah yang memberikan banyak pelajaran tentang keberagaman, kerja keras, dan ketangguhan menghadapi perubahan.
                </p>

                <p>
                    Melangkah dari tanah Papua menuju kota Malang untuk melanjutkan studi bukan sekadar perpindahan tempat tinggal, melainkan perjalanan pembuktian diri dan tanggung jawab. Kehidupan merantau yang panjang melatih saya untuk mandiri, mengelola waktu dengan baik, serta tetap menjaga semangat belajar meski berada jauh dari kampung halaman.
                </p>

                <p>
                    Di dalam kampus, saya mengambil peran aktif dalam dinamika organisasi kemahasiswaan, termasuk dipercaya sebagai salah satu badan pengurus serta terlibat dalam organisasi basket. Pengalaman berorganisasi di lingkungan kampus melatih saya untuk bekerja sama dalam tim, mengatur strategi, menjaga sportivitas, serta mengambil tanggung jawab atas program dan kegiatan bersama.
                </p>

                <p>
                    Sementara itu, di luar kampus atau di lingkungan sosial kemasyarakatan, saya juga aktif berbaur dan berkontribusi sebagai mahasiswa perubahan orang Papua. Keterlibatan di berbagai ruang sosial dan komunitas mengajarkan saya pentingnya empati, komunikasi lintas latar belakang, serta keberanian menyuarakan aspirasi dan gagasan yang membangun bagi sesama.
                </p>

                <p>
                    Bagi saya, menjadi sosok yang berpengaruh di organisasi maupun lingkungan sosial bukan berarti menonjolkan diri, melainkan hadir memberi arah, semangat kebersamaan, dan solusi nyata. Saya percaya mahasiswa Papua memiliki kapasitas besar untuk berkontribusi positif, baik dalam membawa aspirasi kolektif maupun menjalin kolaborasi yang harmonis di tengah masyarakat.
                </p>

                <p>
                    Di tengah kesibukan akademik semester 5, amanah sebagai pengurus organisasi, kegiatan basket, dan persiapan magang, saya terus mengasah keterampilan teknis di bidang pengembangan web. Saya membiasakan diri menyusun struktur halaman dengan HTML dan CSS, merancang tampilan antarmuka yang rapi dan responsif, serta membangun aplikasi web maupun aplikasi mobile menggunakan PHP, MySQL, kerangka kerja Laravel dan saya juga membuka jasa operasi hardware,software.
                </p>

                <p>
                    Entakamala saya hadirkan sebagai ruang digital personal yang menyatukan identitas, perjalanan perantauan, pengalaman organisasi di dalam maupun luar kampus, serta hasil eksplorasi teknologi web yang saya tekuni. Melalui platform ini, saya ingin terus bertumbuh, mendokumentasikan proses belajar, dan membagikan karya yang dapat memberi manfaat bagi banyak orang.
                </p>

                <a href="{{ url('/beranda') }}" class="btn-back">&larr; Kembali ke Beranda</a>
            </div>
        </section>
    </main>

</body>
</html>
