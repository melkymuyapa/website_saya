<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Entakamala</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

  body {
    position: relative;
    background-color: #0f172a;
    background-image: url("{{ asset('image/owapa.png') }}");
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-attachment: fixed;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    min-height: 100vh;
    padding: 16px;
}

/* Lapisan gelap tipis agar kartu/teks di atas foto tetap jelas terbaca */
body::before {
    content: "";
    position: fixed;
    inset: 0;
    background: rgba(10, 20, 40, 0.50);
    z-index: 0;
}

/* Pastikan elemen langsung di dalam body berada di atas lapisan gelap */
body > * {
    position: relative;
    z-index: 1;
}
        .login-card {
            background: #ffffff;
            padding: 30px 49px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-brand {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 18px;
            gap: 8px;
        }

        .login-photo {
            width: 76px;
            height: 76px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #007bff;
            background: #f8fafc;
        }

        .login-card h2 {
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-group input:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn-login {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            border: none;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-login:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: #dc3545;
            font-size: 13px;
            margin-bottom: 15px;
            display: none;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="login-brand">
            <img src="{{ asset('image/logo2.png') }}" alt="Foto Entakamala" class="login-photo">
        </div>

        <h2>Login Entakamala</h2>
        <div id="errorMsg" class="error-message">Username atau password salah!</div>

        <form id="loginForm">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" required placeholder="Masukkan username">
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" required placeholder="Masukkan password">
            </div>

            <button type="submit" class="btn-login">Masuk</button>
        </form>
    </div>

    <script>
        const tujuanSetelahLogin = 'index'; // Ubah ke '/index' jika route beranda kamu memakai /index

        // Cek jika pengguna sudah login, langsung arahkan ke halaman utama
        if (localStorage.getItem('isLoggedIn') === 'true') {
            window.location.href = tujuanSetelahLogin;
        }

        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();

            const usernameInput = document.getElementById('username').value;
            const passwordInput = document.getElementById('password').value;
            const errorMsg = document.getElementById('errorMsg');

            const validUser = "admin";
            const validPass = "123456";

            if (usernameInput === validUser && passwordInput === validPass) {
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('username', usernameInput);

                window.location.href = tujuanSetelahLogin;
            } else {
                errorMsg.style.display = 'block';
            }
        });
    </script>
</body>
</html>
