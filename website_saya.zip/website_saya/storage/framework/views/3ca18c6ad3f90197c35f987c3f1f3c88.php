<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Berita - Entakamala</title>
    <script>
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            window.location.href = '/';
        }

        function logout() {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    </script>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f6f9;
            color: #1e293b;
            line-height: 1.7;
        }

        /* Header */
        .top-header {
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
            padding: 12px 24px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #0f172a;
        }

        .brand img {
            width: 42px;
            height: 42px;
            object-fit: contain;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-text strong {
            font-size: 1rem;
            letter-spacing: 0.5px;
            color: #0f172a;
        }

        .brand-text span {
            font-size: 0.75rem;
            color: #64748b;
        }

        .btn-logout {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            background: #ef4444;
            color: #ffffff;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .btn-logout:hover {
            background: #dc2626;
        }

        /* Konten Utama */
        .news-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 36px 24px;
            display: grid;
            gap: 24px;
        }

        .news-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 32px;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.05);
        }

        .badge {
            display: inline-block;
            background-color: #eff6ff;
            color: #2563eb;
            font-size: 0.8rem;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 10px;
        }

        .news-card h1 {
            font-size: 1.75rem;
            color: #0f172a;
            margin-bottom: 8px;
        }

        .news-card h2 {
            font-size: 1.3rem;
            color: #0f172a;
            margin-bottom: 14px;
        }

        .subtitle {
            color: #475569;
            font-size: 15px;
            margin-bottom: 24px;
        }

        .news-form {
            display: grid;
            gap: 16px;
        }

        .form-grid-2 {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .form-group label {
            font-size: 14px;
            font-weight: 600;
            color: #0f172a;
        }

        .form-group input[type="text"],
        .form-group textarea,
        .form-group input[type="file"] {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 14px;
            background: #ffffff;
            color: #1e293b;
        }

        .form-group input[type="file"] {
            padding: 8px;
            background: #f8fafc;
        }

        .hint {
            font-size: 12px;
            color: #64748b;
        }

        .form-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            margin-top: 8px;
        }

        .btn-submit {
            padding: 10px 22px;
            border: none;
            border-radius: 8px;
            background: #2563eb;
            color: #ffffff;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .btn-submit:hover {
            background: #1d4ed8;
        }

        .btn-back {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            background: #0f172a;
            color: #ffffff;
            font-size: 0.95rem;
            font-weight: 500;
            transition: background-color 0.2s;
        }

        .btn-back:hover {
            background: #334155;
        }

        .alert-info {
            display: none;
            padding: 12px 16px;
            border-radius: 8px;
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            color: #1d4ed8;
            font-size: 14px;
            margin-bottom: 16px;
        }

        /* Daftar Berita */
        .news-list {
            display: grid;
            gap: 18px;
        }

        .news-item {
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            background: #f8fafc;
        }

        .news-item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 8px;
        }

        .news-item h3 {
            font-size: 1.15rem;
            color: #0f172a;
        }

        .news-date {
            font-size: 12px;
            color: #64748b;
            white-space: nowrap;
        }

        .news-item p {
            color: #475569;
            font-size: 14.5px;
            margin-bottom: 14px;
            white-space: pre-line;
        }

        .media-preview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
            margin-bottom: 14px;
        }

        .media-preview img,
        .media-preview video {
            width: 100%;
            max-height: 240px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            background: #000000;
        }

        .doc-links {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 12px;
        }

        .doc-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 12px;
            border-radius: 6px;
            background: #ffffff;
            border: 1px solid #cbd5e1;
            color: #0f172a;
            font-size: 13px;
            font-weight: 500;
            text-decoration: none;
        }

        .doc-link:hover {
            border-color: #2563eb;
            color: #2563eb;
        }

        .btn-delete {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            background: #fee2e2;
            color: #b91c1c;
            font-size: 12.5px;
            font-weight: 600;
            cursor: pointer;
        }

        .btn-delete:hover {
            background: #fecaca;
        }

        @media (max-width: 768px) {
            .news-card {
                padding: 22px;
            }

            .form-grid-2 {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <header class="top-header">
        <div class="header-inner">
            <a href="<?php echo e(url('/beranda')); ?>" class="brand">
                <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Logo Entakamala">
                <div class="brand-text">
                    <strong>ENTAKAMALA</strong>
                    <span>Digital &amp; Personal Web</span>
                </div>
            </a>

            <button type="button" class="btn-logout" onclick="logout()">Logout</button>
        </div>
    </header>

    <main class="news-container">
        <section class="news-card">
            <span class="badge">Blog &amp; Berita</span>
            <h1>Update Berita</h1>
            <p class="subtitle">Publikasikan informasi terbaru lengkap dengan foto, video, dokumen PDF, maupun file Word.</p>

            <div id="statusAlert" class="alert-info"></div>

            <form id="beritaForm" class="news-form" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="judulBerita">Judul Berita *</label>
                    <input type="text" id="judulBerita" name="judul" placeholder="Contoh: Kegiatan Mahasiswa &amp; Proyek Laravel Entakamala" required>
                </div>

                <div class="form-group">
                    <label for="isiBerita">Isi / Ringkasan Berita *</label>
                    <textarea id="isiBerita" name="isi" rows="4" placeholder="Tulis detail berita di sini..." required></textarea>
                </div>

                <div class="form-grid-2">
                    <div class="form-group">
                        <label for="fileFoto">Upload Foto (Gambar)</label>
                        <input type="file" id="fileFoto" name="foto" accept="image/*">
                        <span class="hint">Format: JPG, PNG, WEBP, GIF</span>
                    </div>

                    <div class="form-group">
                        <label for="fileVideo">Upload Video</label>
                        <input type="file" id="fileVideo" name="video" accept="video/*">
                        <span class="hint">Format: MP4, WEBM, OGG</span>
                    </div>

                    <div class="form-group">
                        <label for="filePdf">Upload Dokumen PDF</label>
                        <input type="file" id="filePdf" name="pdf" accept=".pdf,application/pdf">
                        <span class="hint">Format: .pdf</span>
                    </div>

                    <div class="form-group">
                        <label for="fileWord">Upload Dokumen Word</label>
                        <input type="file" id="fileWord" name="word" accept=".doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
                        <span class="hint">Format: .doc, .docx</span>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn-submit">Simpan &amp; Publikasikan Berita</button>
                    <a href="<?php echo e(url('/beranda')); ?>" class="btn-back">&larr; Kembali ke Beranda</a>
                </div>
            </form>
        </section>

        <section class="news-card">
            <h2>Daftar Berita Terupdate</h2>
            <div id="daftarBerita" class="news-list">
                <p class="hint">Belum ada berita yang ditambahkan.</p>
            </div>
        </section>
    </main>

    <script>
        const STORAGE_KEY = 'entakamala_berita_list';

        function readFileAsDataUrl(file) {
            return new Promise((resolve, reject) => {
                if (!file) return resolve(null);
                const reader = new FileReader();
                reader.onload = () => resolve({
                    name: file.name,
                    type: file.type,
                    dataUrl: reader.result
                });
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }

        function getBeritaList() {
            try {
                return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
            } catch (e) {
                return [];
            }
        }

        function saveBeritaList(list) {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
        }

        function showAlert(message) {
            const alertBox = document.getElementById('statusAlert');
            alertBox.textContent = message;
            alertBox.style.display = 'block';
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function renderBerita() {
            const container = document.getElementById('daftarBerita');
            const list = getBeritaList();

            if (!list.length) {
                container.innerHTML = '<p class="hint">Belum ada berita yang ditambahkan.</p>';
                return;
            }

            container.innerHTML = list.map((item) => {
                let mediaHtml = '';
                if (item.foto || item.video) {
                    mediaHtml += '<div class="media-preview">';
                    if (item.foto) {
                        mediaHtml += `<img src="${item.foto.dataUrl}" alt="${escapeHtml(item.foto.name)}">`;
                    }
                    if (item.video) {
                        mediaHtml += `<video controls src="${item.video.dataUrl}"></video>`;
                    }
                    mediaHtml += '</div>';
                }

                let docsHtml = '';
                if (item.pdf || item.word) {
                    docsHtml += '<div class="doc-links">';
                    if (item.pdf) {
                        docsHtml += `<a class="doc-link" href="${item.pdf.dataUrl}" download="${escapeHtml(item.pdf.name)}">&#128196; PDF: ${escapeHtml(item.pdf.name)}</a>`;
                    }
                    if (item.word) {
                        docsHtml += `<a class="doc-link" href="${item.word.dataUrl}" download="${escapeHtml(item.word.name)}">&#128221; Word: ${escapeHtml(item.word.name)}</a>`;
                    }
                    docsHtml += '</div>';
                }

                return `
                    <article class="news-item">
                        <div class="news-item-header">
                            <h3>${escapeHtml(item.judul)}</h3>
                            <span class="news-date">${escapeHtml(item.tanggal)}</span>
                        </div>
                        <p>${escapeHtml(item.isi)}</p>
                        ${mediaHtml}
                        ${docsHtml}
                        <button type="button" class="btn-delete" onclick="hapusBerita('${item.id}')">Hapus</button>
                    </article>
                `;
            }).join('');
        }

        function hapusBerita(id) {
            const updated = getBeritaList().filter((item) => item.id !== id);
            saveBeritaList(updated);
            renderBerita();
            showAlert('Berita berhasil dihapus.');
        }

        document.getElementById('beritaForm').addEventListener('submit', async function (e) {
            e.preventDefault();

            const judul = document.getElementById('judulBerita').value.trim();
            const isi = document.getElementById('isiBerita').value.trim();
            const fotoFile = document.getElementById('fileFoto').files[0];
            const videoFile = document.getElementById('fileVideo').files[0];
            const pdfFile = document.getElementById('filePdf').files[0];
            const wordFile = document.getElementById('fileWord').files[0];

            try {
                const [foto, video, pdf, word] = await Promise.all([
                    readFileAsDataUrl(fotoFile),
                    readFileAsDataUrl(videoFile),
                    readFileAsDataUrl(pdfFile),
                    readFileAsDataUrl(wordFile)
                ]);

                const newItem = {
                    id: String(Date.now()),
                    judul,
                    isi,
                    tanggal: new Date().toLocaleString('id-ID'),
                    foto,
                    video,
                    pdf,
                    word
                };

                const currentList = getBeritaList();
                currentList.unshift(newItem);
                saveBeritaList(currentList);

                this.reset();
                renderBerita();
                showAlert('Berita dan lampiran berhasil disimpan!');
            } catch (err) {
                showAlert('Gagal memproses file. Coba gunakan file dengan ukuran lebih kecil atau simpan ke server Laravel.');
            }
        });

        renderBerita();
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\website_saya\resources\views/Halaman/Blog/update-berita.blade.php ENDPATH**/ ?>