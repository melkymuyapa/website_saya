<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Web - Entakamala</title>
    <script>
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            window.location.href = '/';
        }

        function logout() {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    </script>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f6f9;
            color: #1e293b;
            line-height: 1.7;
        }

        /* Top Navbar */
        .top-header {
            position: sticky;
            top: 0;
            width: 100%;
            background: #ffffff;
            box-shadow: 0 2px 12px rgba(15, 23, 42, 0.06);
            z-index: 1000;
        }

        .navbar-container {
            max-width: 1140px;
            margin: 0 auto;
            padding: 10px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            flex-shrink: 0;
        }

        .brand-logo2 {
            width: 38px;
            height: 38px;
            object-fit: contain;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
            line-height: 1.15;
        }

        .brand-text strong {
            font-size: 16px;
            font-weight: 800;
            color: #0b2e8a;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        .brand-text span {
            font-size: 10px;
            font-weight: 600;
            color: #1d4ed8;
            letter-spacing: 0.7px;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .nav-menu > a,
        .nav-menu .dropdown-trigger {
            text-decoration: none;
            color: #1e293b;
            font-size: 14px;
            font-weight: 500;
            white-space: nowrap;
            transition: color 0.2s ease;
        }

        .nav-menu > a:hover,
        .nav-dropdown:hover .dropdown-trigger,
        .nav-dropdown .dropdown-trigger.active {
            color: #1d4ed8;
            font-weight: 600;
        }

        .nav-dropdown {
            position: relative;
            display: flex;
            align-items: center;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: calc(100% + 10px);
            left: 0;
            min-width: 215px;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 8px;
            box-shadow: 0 10px 28px rgba(15, 23, 42, 0.12);
            flex-direction: column;
            gap: 2px;
            z-index: 1100;
        }

        .dropdown-menu::before {
            content: "";
            position: absolute;
            top: -12px;
            left: 0;
            right: 0;
            height: 12px;
        }

        .nav-dropdown:hover .dropdown-menu,
        .nav-dropdown:focus-within .dropdown-menu {
            display: flex;
        }

        .dropdown-menu a {
            display: block;
            text-decoration: none;
            padding: 9px 12px;
            border-radius: 7px;
            font-size: 13.5px;
            font-weight: 500;
            color: #1e293b;
            white-space: nowrap;
            transition: background 0.15s ease, color 0.15s ease;
        }

        .dropdown-menu a:hover {
            background: #eff6ff;
            color: #1d4ed8;
            font-weight: 600;
        }

        .btn-logout {
            padding: 7px 14px;
            background: #ef4444;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-size: 12.5px;
            font-weight: 600;
            white-space: nowrap;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        .btn-logout:hover {
            background: #dc2626;
        }

        /* Konten Utama */
        main {
            max-width: 1140px;
            margin: 0 auto;
            padding: 36px 24px 60px;
        }

        .content-card {
            background: #ffffff;
            padding: 36px;
            border-radius: 14px;
            box-shadow: 0 6px 24px rgba(15, 23, 42, 0.06);
            border: 1px solid #e2e8f0;
            display: grid;
            grid-template-columns: 0.85fr 1.15fr;
            gap: 32px;
            align-items: start;
        }

        .card-media {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card-photo {
            width: 100%;
            max-width: 280px;
            max-height: 300px;
            object-fit: contain;
            border-radius: 8px;
            display: block;
        }

        .badge {
            display: inline-block;
            background-color: #eff6ff;
            color: #2563eb;
            font-size: 0.8rem;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 12px;
        }

        .card-body h1 {
            font-size: 1.7rem;
            color: #0f172a;
            margin-bottom: 12px;
        }

        .card-body h2 {
            font-size: 1.05rem;
            color: #0b2e8a;
            margin-top: 14px;
            margin-bottom: 8px;
        }

        .card-body p {
            color: #475569;
            font-size: 15px;
            margin-bottom: 14px;
        }

        .feature-list {
            color: #475569;
            font-size: 14.5px;
            padding-left: 20px;
            margin-bottom: 24px;
        }

        .feature-list li {
            margin-bottom: 8px;
        }

        .btn-primary {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            background: #2563eb;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: 600;
            transition: background 0.2s ease;
        }

        .btn-primary:hover {
            background: #1d4ed8;
        }

        @media (max-width: 768px) {
            .navbar-container {
                flex-direction: column;
                align-items: flex-start;
            }

            .nav-right {
                width: 100%;
                justify-content: space-between;
                flex-wrap: wrap;
                gap: 8px;
            }

            .nav-menu {
                flex-wrap: wrap;
                gap: 10px;
            }

            .content-card {
                grid-template-columns: 1fr;
                padding: 24px;
            }
        }
    </style>
</head>
<body>

    <header class="top-header">
        <div class="navbar-container">
            <a href="<?php echo e(url('/beranda')); ?>" class="brand">
                <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Logo2 Entakamala" class="brand-logo2">
                <div class="brand-text">
                    <strong>ENTAKAMALA</strong>
                    <span>Digital &amp; Personal Web</span>
                </div>
            </a>

            <div class="nav-right">
                <nav class="nav-menu" aria-label="Navigasi Utama">
                    <a href="<?php echo e(url('/beranda')); ?>">Beranda</a>

                    <div class="nav-dropdown">
                        <a href="<?php echo e(url('/Submenu/pengembangan-web')); ?>" class="dropdown-trigger">Layanan &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Submenu/pengembangan-web')); ?>">Pengembangan Web</a>
                            <a href="<?php echo e(url('/Submenu/desain-ui-ux')); ?>">Desain UI/UX</a>
                            <a href="<?php echo e(url('/Submenu/konsultasi-digital')); ?>">Konsultasi Digital</a>
                        </div>
                    </div>

                    <div class="nav-dropdown">
                        <a href="<?php echo e(url('/Tentang/profil')); ?>" class="dropdown-trigger">Tentang Kami &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Tentang/profil')); ?>">Profil Entakamala</a>
                            <a href="<?php echo e(url('/Tentang/visi-misi')); ?>">Visi &amp; Misi</a>
                        </div>
                    </div>

                    <div class="nav-dropdown">
                        <a href="<?php echo e(url('/Portofolio/sistem-informasi')); ?>" class="dropdown-trigger active">Portofolio &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Portofolio/sistem-informasi')); ?>">Sistem Informasi Web</a>
                            <a href="<?php echo e(url('/Portofolio/company-profile')); ?>">Company Profile Modern</a>
                        </div>
                    </div>

                    <div class="nav-dropdown">
                        <a href="<?php echo e(url('/Blog/html-css')); ?>" class="dropdown-trigger">Blog &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Blog/html-css')); ?>">Struktur HTML &amp; CSS</a>
                            <a href="<?php echo e(url('/Blog/belajar-laravel')); ?>">Belajar Laravel</a>
                            <a href="<?php echo e(url('/Blog/update-berita')); ?>">Update Berita</a>
                        </div>
                    </div>
                </nav>

                <button type="button" class="btn-logout" onclick="logout()">Logout</button>
            </div>
        </div>
    </header>

    <main>
        <section class="content-card">
            <div class="card-media">
                <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Sistem Informasi Web Entakamala" class="card-photo">
            </div>

            <div class="card-body">
                <span class="badge">Portofolio</span>
                <h1>Sistem Informasi Web</h1>

                <p>
                    Pengembangan sistem informasi berbasis web yang berfokus pada alur autentikasi pengguna, pengelolaan data terstruktur, serta antarmuka yang rapi dan responsif untuk kebutuhan operasional maupun pembelajaran.
                </p>

                <h2>Komponen Utama Sistem</h2>
                <ul class="feature-list">
                    <li><strong>Autentikasi &amp; Kontrol Akses:</strong> Validasi kredensial pengguna (seperti alur login dan penanganan sesi/status akses) agar halaman internal lebih terarah dan aman.</li>
                    <li><strong>Basis Data Terstruktur:</strong> Penyimpanan dan relasi data menggunakan MySQL / phpMyAdmin dengan struktur tabel yang jelas untuk mendukung pencatatan dan pencarian informasi.</li>
                    <li><strong>Antarmuka &amp; Navigasi Web:</strong> Tata letak kartu yang konsisten, menu navigasi terstruktur, serta tampilan yang menyesuaikan ukuran layar desktop maupun mobile.</li>
                    <li><strong>Pendekatan Pengguna &amp; Etika Data:</strong> Perancangan fitur yang memperhatikan kenyamanan pengguna, kejelasan informasi, serta perlindungan data.</li>
                </ul>

                <a href="<?php echo e(url('/beranda')); ?>" class="btn-primary">&larr; Kembali ke Beranda</a>
            </div>
        </section>
    </main>

</body>
</html>
<?php /**PATH C:\laragon\www\website_saya\resources\views/Halaman/Portofolio/sistem-informasi.blade.php ENDPATH**/ ?>