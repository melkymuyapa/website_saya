<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struktur HTML - Entakamala</title>
    <script>
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            window.location.href = '/';
        }

        function logout() {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    </script>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f6f9;
            color: #1e293b;
            line-height: 1.7;
        }

        /* Header */
        .top-header {
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
            padding: 12px 24px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #0f172a;
        }

        .brand img {
            width: 42px;
            height: 42px;
            object-fit: contain;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-text strong {
            font-size: 1rem;
            letter-spacing: 0.5px;
            color: #0f172a;
        }

        .brand-text span {
            font-size: 0.75rem;
            color: #64748b;
        }

        .btn-logout {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            background: #ef4444;
            color: #ffffff;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .btn-logout:hover {
            background: #dc2626;
        }

        /* Konten Utama */
        .submenu-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 36px 24px;
        }

        .submenu-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 36px;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.05);
            display: grid;
            grid-template-columns: 0.85fr 1.15fr;
            gap: 32px;
            align-items: start;
        }

        .submenu-media {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .submenu-photo {
            width: 100%;
            max-width: 280px;
            max-height: 300px;
            object-fit: contain;
            border-radius: 8px;
            display: block;
        }

        .badge {
            display: inline-block;
            background-color: #eff6ff;
            color: #2563eb;
            font-size: 0.8rem;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 12px;
        }

        .submenu-text h1 {
            font-size: 1.75rem;
            color: #0f172a;
            margin-bottom: 12px;
        }

        .submenu-text h2 {
            font-size: 1.05rem;
            color: #0f172a;
            margin-top: 14px;
            margin-bottom: 8px;
        }

        .submenu-text p {
            color: #475569;
            font-size: 15px;
            margin-bottom: 14px;
        }

        .step-list {
            color: #475569;
            font-size: 15px;
            padding-left: 20px;
            margin-bottom: 24px;
        }

        .step-list li {
            margin-bottom: 8px;
        }

        .btn-back {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            background: #2563eb;
            color: #ffffff;
            font-size: 0.95rem;
            font-weight: 500;
            transition: background-color 0.2s;
        }

        .btn-back:hover {
            background: #1d4ed8;
        }

        @media (max-width: 768px) {
            .submenu-card {
                grid-template-columns: 1fr;
                padding: 24px;
            }
        }
    </style>
</head>
<body>

    <header class="top-header">
        <div class="header-inner">
            <a href="<?php echo e(url('/beranda')); ?>" class="brand">
                <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Logo Entakamala">
                <div class="brand-text">
                    <strong>ENTAKAMALA</strong>
                    <span>Digital &amp; Personal Web</span>
                </div>
            </a>

            <button type="button" class="btn-logout" onclick="logout()">Logout</button>
        </div>
    </header>

    <main class="submenu-container">
        <section class="submenu-card">
            <div class="submenu-media">
                <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Struktur HTML" class="submenu-photo">
            </div>

            <div class="submenu-text">
                <span class="badge">Blog</span>
                <h1>Struktur HTML &amp; Langkah Kerjanya</h1>

                <p>
                    Struktur HTML (HyperText Markup Language) berfungsi membentuk kerangka dasar halaman web mulai dari deklarasi dokumen, bagian kepala (<code>&lt;head&gt;</code>), hingga isi utama yang tampil di browser (<code>&lt;body&gt;</code>).
                </p>

                <h2>Langkah Kerja Menyusun Struktur HTML</h2>
                <ol class="step-list">
                    <li><strong>Deklarasi Dokumen:</strong> Mulai dengan <code>&lt;!DOCTYPE html&gt;</code> dan bungkus seluruh halaman di dalam tag <code>&lt;html&gt;</code>.</li>
                    <li><strong>Konfigurasi Kepala Halaman:</strong> Isi bagian <code>&lt;head&gt;</code> dengan <code>&lt;meta charset="UTF-8"&gt;</code>, <code>&lt;meta name="viewport"&gt;</code>, <code>&lt;title&gt;</code>, serta gaya atau skrip pendukung.</li>
                    <li><strong>Kerangka Semantik Konten:</strong> Susun isi halaman di dalam <code>&lt;body&gt;</code> menggunakan elemen semantik seperti <code>&lt;header&gt;</code>, <code>&lt;nav&gt;</code>, <code>&lt;main&gt;</code>, <code>&lt;section&gt;</code>, dan <code>&lt;footer&gt;</code>.</li>
                    <li><strong>Pengisian Elemen &amp; Tautan:</strong> Tambahkan judul, paragraf, gambar, tombol, dan navigasi dengan penulisan tag yang tertutup rapi.</li>
                    <li><strong>Uji Tampilan di Browser:</strong> Jalankan dan periksa tampilan halaman di desktop maupun mobile serta perbaiki jika ada tata letak yang belum sesuai.</li>
                </ol>

                <a href="<?php echo e(url('/home')); ?>" class="btn-back">&larr; Kembali ke Beranda</a>
            </div>
        </section>
    </main>

</body>
</html>
<?php /**PATH C:\laragon\www\website_saya\resources\views/Halaman/Blog/html-css.blade.php ENDPATH**/ ?>