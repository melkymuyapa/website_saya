<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website - Entakamala</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f4f6f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-card {
            background: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-card h2 {
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-group input:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn-login {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            border: none;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-login:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: #dc3545;
            font-size: 13px;
            margin-bottom: 15px;
            display: none;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <h2>Login Entakamala</h2>
        <div id="errorMsg" class="error-message">Username atau password salah!</div>

        <form id="loginForm">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" required placeholder="Masukkan username">
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" required placeholder="Masukkan password">
            </div>

            <button type="submit" class="btn-login">Masuk</button>
        </form>
    </div>

    <script>
        // Cek jika pengguna sudah login, arahkan ke rute /index
        if (localStorage.getItem('isLoggedIn') === 'true') {
            window.location.href = '/index';
        }

        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();

            const usernameInput = document.getElementById('username').value;
            const passwordInput = document.getElementById('password').value;
            const errorMsg = document.getElementById('errorMsg');

            const validUser = "admin";
            const validPass = "123456";

            if (usernameInput === validUser && passwordInput === validPass) {
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('username', usernameInput);

                // Pindah ke rute /index
                window.location.href = '/index';
            } else {
                errorMsg.style.display = 'block';
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\website_saya\resources\views/welcome.blade.php ENDPATH**/ ?>