<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda - Entakamala</title>
    <script>
        // Jika belum login, kembalikan ke halaman login (/)
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            window.location.href = '/';
        }

        function logout() {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    </script>
  <style>
    /* Reset CSS */
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    html {
        scroll-behavior: smooth;
        scroll-padding-top: 72px;
    }

    body {
        background-color: #f8fafc;
        color: #1e293b;
        line-height: 1.6;
    }

    /* Top Navbar Putih */
    .top-header {
        position: sticky;
        top: 0;
        width: 100%;
        background: #ffffff;
        box-shadow: 0 2px 12px rgba(15, 23, 42, 0.06);
        z-index: 1000;
    }

    .navbar-container {
        max-width: 1140px;
        margin: 0 auto;
        padding: 10px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
    }

    /* Logo & Brand */
    .brand {
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        flex-shrink: 0;
    }

    .brand-logo,
    .brand-logo2 {
        width: 36px;
        height: 36px;
        max-width: 36px;
        max-height: 36px;
        object-fit: cover;
        border-radius: 6px;
        flex-shrink: 0;
    }

    .brand-halaman {
        width: 38px;
        height: 38px;
        max-width: 38px;
        max-height: 38px;
        object-fit: cover;
        border-radius: 50%;
        border: 2px solid #ffffff;
        background: #ffffff;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
        flex-shrink: 0;
    }

    .brand-text {
        display: flex;
        flex-direction: column;
        line-height: 1.15;
    }

    .top-header .brand-text strong {
        font-size: 16px;
        font-weight: 800;
        color: #0b2e8a;
        letter-spacing: 0.5px;
        white-space: nowrap;
    }

    .top-header .brand-text span {
        font-size: 9px;
        font-weight: 600;
        color: #1d4ed8;
        letter-spacing: 0.7px;
        text-transform: uppercase;
        white-space: nowrap;
    }

    .hero-banner .brand-text strong {
        font-size: 16px;
        font-weight: 800;
        color: #ffffff;
        letter-spacing: 0.5px;
    }

    .hero-banner .brand-text span {
        font-size: 10px;
        font-weight: 600;
        color: #cbd5e1;
        letter-spacing: 0.7px;
        text-transform: uppercase;
    }

    /* Menu Kanan */
    .nav-right {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .nav-menu {
        display: flex;
        align-items: center;
        gap: 18px;
    }

    .nav-menu > a,
    .nav-menu .dropdown-trigger {
        text-decoration: none;
        color: #1e293b;
        font-size: 14px;
        font-weight: 500;
        white-space: nowrap;
        transition: color 0.2s ease;
    }

    .nav-menu > a:hover,
    .nav-menu > a.active,
    .nav-dropdown:hover .dropdown-trigger,
    .nav-dropdown .dropdown-trigger.active {
        color: #1d4ed8;
        font-weight: 600;
    }

    /* Dropdown Menu di Navbar */
    .nav-dropdown {
        position: relative;
        display: flex;
        align-items: center;
    }

    .dropdown-trigger {
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }

    .dropdown-menu {
        display: none;
        position: absolute;
        top: calc(100% + 10px);
        left: 0;
        min-width: 215px;
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 8px;
        box-shadow: 0 10px 28px rgba(15, 23, 42, 0.12);
        flex-direction: column;
        gap: 2px;
        z-index: 1100;
    }

    /* Jembatan tak terlihat agar kursor tidak putus saat turun ke submenu */
    .dropdown-menu::before {
        content: "";
        position: absolute;
        top: -12px;
        left: 0;
        right: 0;
        height: 12px;
    }

    .nav-dropdown:hover .dropdown-menu,
    .nav-dropdown:focus-within .dropdown-menu {
        display: flex;
    }

    .dropdown-menu a {
        display: block;
        text-decoration: none;
        padding: 9px 12px;
        border-radius: 7px;
        font-size: 13.5px;
        font-weight: 500;
        color: #1e293b;
        white-space: nowrap;
        transition: background 0.15s ease, color 0.15s ease;
    }

    .dropdown-menu a:hover {
        background: #eff6ff;
        color: #1d4ed8;
        font-weight: 600;
    }

    .btn-logout {
        padding: 6px 12px;
        background: #ef4444;
        color: #ffffff;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        white-space: nowrap;
        cursor: pointer;
        transition: background 0.2s ease;
    }

    .btn-logout:hover {
        background: #dc2626;
    }

    /* Hero Banner dengan Foto Latar */
    .hero-banner {
        position: relative;
        min-height: 420px;
        width: 100%;
        display: flex;
        align-items: center;
        overflow: hidden;
        background-color: #0f172a;
        background-image: url("<?php echo e(asset('image/halaman .png')); ?>");
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }

    .hero-banner::after {
        content: "";
        position: absolute;
        inset: 0;
        background: linear-gradient(90deg, rgba(15, 23, 42, 0.75) 0%, rgba(15, 23, 42, 0.45) 100%);
        z-index: 0;
    }

    .hero-inner {
        position: relative;
        z-index: 1;
        max-width: 1140px;
        width: 100%;
        margin: 0 auto;
        padding: 60px 24px;
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .hero-visual {
        display: flex;
        align-items: center;
    }

    .hero-content {
        max-width: 650px;
        color: #ffffff;
    }

    .hero-content h1 {
        font-size: 2.5rem;
        font-weight: 700;
        color: #ffffff;
        margin-bottom: 10px;
    }

    .hero-sub {
        display: flex;
        align-items: center;
        gap: 10px;
        color: #e2e8f0;
        font-size: 15px;
    }

    .hero-sub .arrow {
        color: #60a5fa;
        font-weight: 700;
    }

    /* Kontainer Section Utama */
    main {
        max-width: 1140px;
        margin: 0 auto;
        padding: 0 24px 80px;
    }

    .content-card {
        background: #ffffff;
        padding: 32px;
        border-radius: 14px;
        margin-bottom: 24px;
        box-shadow: 0 6px 24px rgba(15, 23, 42, 0.06);
        border: 1px solid #e2e8f0;
    }

    .overlap-card {
        position: relative;
        z-index: 2;
        margin-top: -36px;
    }

    .content-card h2 {
        font-size: 1.4rem;
        color: #0b2e8a;
        margin-bottom: 12px;
    }

    .content-card p {
        color: #475569;
    }

    /* Grid untuk Home, Layanan, Portofolio, Blog */
    .grid-3 {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 18px;
        margin-top: 18px;
    }

    .item-box {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 20px;
        transition: border-color 0.2s ease, transform 0.2s ease;
    }

    a.item-box:hover {
        border-color: #2563eb;
        transform: translateY(-2px);
    }

    .item-box h3 {
        font-size: 1.05rem;
        color: #0f172a;
        margin-bottom: 6px;
    }

    /* Form Kontak */
    .contact-form {
        display: grid;
        gap: 12px;
        max-width: 520px;
        margin-top: 16px;
    }

    .contact-form input,
    .contact-form textarea {
        padding: 11px 14px;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        font-size: 14px;
    }

    .btn-primary {
        width: fit-content;
        padding: 10px 22px;
        background: #0b2e8a;
        color: #ffffff;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.2s ease;
    }

    .btn-primary:hover {
        background: #1d4ed8;
    }

    /* Grup Tombol Melayang di Kiri Bawah */
    .social-float-group {
        position: fixed;
        left: 20px;
        bottom: 20px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 12px;
        align-items: center;
    }

    /* Gaya Dasar Setiap Tombol */
    .social-float-btn {
        position: relative;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        background-color: #334155;
        text-decoration: none;
        box-shadow: 0 6px 18px rgba(15, 23, 42, 0.22);
        transition: transform 0.2s ease, box-shadow 0.2s ease, filter 0.2s ease;
    }

    .social-float-btn:hover,
    .social-float-btn:focus-visible {
        transform: translateY(-2px) scale(1.05);
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.3);
        filter: brightness(1.06);
        outline: none;
    }

    /* Label Tooltip di Samping Kanan Tombol */
    .social-float-btn::after {
        content: attr(data-tooltip);
        position: absolute;
        left: calc(100% + 12px);
        top: 50%;
        transform: translateY(-50%) translateX(-6px);
        padding: 6px 11px;
        border-radius: 8px;
        background-color: #0f172a;
        color: #ffffff;
        font-size: 13px;
        font-weight: 500;
        line-height: 1.2;
        white-space: nowrap;
        box-shadow: 0 6px 16px rgba(15, 23, 42, 0.25);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.2s ease, transform 0.2s ease;
    }

    .social-float-btn:hover::after,
    .social-float-btn:focus-visible::after {
        opacity: 1;
        transform: translateY(-50%) translateX(0);
    }

    /* Navbar Bawah Media Sosial - Rata Tengah */
    .social-bottom-bar {
        max-width: 1140px;
        margin: 28px auto 48px auto;
        padding: 0 24px;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .social-bottom-group {
        display: inline-flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
        gap: 14px;
        padding: 12px 22px;
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 999px;
        box-shadow: 0 6px 20px rgba(15, 23, 42, 0.06);
    }

    .social-bottom-btn {
        position: relative;
        width: 44px;
        height: 44px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        text-decoration: none;
        box-shadow: 0 4px 10px rgba(15, 23, 42, 0.14);
        transition: transform 0.2s ease, box-shadow 0.2s ease, filter 0.2s ease;
    }

    .social-bottom-btn:hover,
    .social-bottom-btn:focus-visible {
        transform: translateY(-3px) scale(1.05);
        box-shadow: 0 8px 16px rgba(15, 23, 42, 0.22);
        filter: brightness(1.06);
        outline: none;
    }

    /* Warna Khusus Per Kanal */
    .float-wa { background-color: #25d366; }
    .float-ig { background: linear-gradient(45deg, #f58529, #dd2a7b, #8134af, #515bd4); }
    .float-fb { background-color: #1877f2; }
    .float-li { background-color: #0a66c2; }
    .float-tt { background-color: #0f172a; }
    .float-email { background-color: #ea4335; }

    /* Tombol & Panel Chat AI ke Admin di Kanan Bawah */
    .ai-chat-launcher {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 11px 18px;
        border: none;
        border-radius: 999px;
        background: #0b2e8a;
        color: #ffffff;
        font-size: 13.5px;
        font-weight: 700;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        box-shadow: 0 6px 18px rgba(11, 46, 138, 0.35);
        z-index: 1001;
        transition: background 0.2s ease, transform 0.2s ease;
    }

    .ai-chat-launcher:hover {
        background: #1d4ed8;
        transform: translateY(-2px);
    }

    .ai-chat-panel {
        display: none;
        position: fixed;
        bottom: 78px;
        right: 20px;
        width: 340px;
        max-width: calc(100vw - 32px);
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        box-shadow: 0 14px 36px rgba(15, 23, 42, 0.18);
        overflow: hidden;
        z-index: 1002;
        flex-direction: column;
    }

    .ai-chat-panel.open {
        display: flex;
    }

    .ai-chat-header {
        background: #0b2e8a;
        color: #ffffff;
        padding: 12px 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .ai-chat-header strong {
        font-size: 14px;
        display: block;
    }

    .ai-chat-header span {
        font-size: 11px;
        color: #bfdbfe;
    }

    .ai-chat-close {
        background: transparent;
        border: none;
        color: #ffffff;
        font-size: 20px;
        line-height: 1;
        cursor: pointer;
        padding: 0 4px;
    }

    .ai-chat-messages {
        padding: 14px;
        height: 240px;
        overflow-y: auto;
        background: #f8fafc;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .chat-msg {
        max-width: 85%;
        padding: 9px 12px;
        border-radius: 10px;
        font-size: 13px;
        line-height: 1.45;
        word-wrap: break-word;
    }

    .chat-msg.admin {
        align-self: flex-start;
        background: #ffffff;
        color: #1e293b;
        border: 1px solid #e2e8f0;
    }

    .chat-msg.user {
        align-self: flex-end;
        background: #2563eb;
        color: #ffffff;
    }

    .ai-chat-form {
        display: flex;
        gap: 8px;
        padding: 10px;
        background: #ffffff;
        border-top: 1px solid #e2e8f0;
    }

    .ai-chat-form input {
        flex: 1;
        padding: 8px 12px;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        font-size: 13px;
    }

    .ai-chat-send {
        padding: 8px 14px;
        border: none;
        border-radius: 8px;
        background: #0b2e8a;
        color: #ffffff;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
    }

    .ai-chat-send:hover {
        background: #1d4ed8;
    }

    /* Responsif Layar Kecil */
    @media (max-width: 768px) {
        .navbar-container {
            flex-direction: column;
            align-items: flex-start;
            padding: 10px 16px;
        }

        .nav-right {
            width: 100%;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 8px;
        }

        .nav-menu {
            gap: 10px;
            flex-wrap: wrap;
        }

        .nav-menu > a,
        .nav-menu .dropdown-trigger {
            font-size: 12.5px;
        }

        .nav-dropdown {
            flex-direction: column;
            align-items: flex-start;
        }

        .dropdown-menu {
            position: static;
            box-shadow: none;
            border: none;
            background: #f8fafc;
            margin-top: 6px;
            min-width: 100%;
            padding: 6px 10px;
        }

        .dropdown-menu::before {
            display: none;
        }

        .nav-dropdown.open .dropdown-menu {
            display: flex;
        }

        .hero-content h1 {
            font-size: 1.85rem;
        }

        .hero-sub {
            font-size: 13.5px;
        }

        .content-card {
            padding: 24px;
        }
    }

    @media (max-width: 600px) {
        .social-float-group {
            left: 14px;
            bottom: 14px;
            gap: 10px;
        }

        .social-float-btn {
            width: 42px;
            height: 42px;
        }

        .social-float-btn::after {
            font-size: 12px;
            padding: 5px 9px;
            left: calc(100% + 10px);
        }

        .social-bottom-bar {
            margin: 20px auto 36px auto;
            padding: 0 16px;
        }

        .social-bottom-group {
            gap: 10px;
            padding: 10px 14px;
            border-radius: 24px;
        }

        .social-bottom-btn {
            width: 40px;
            height: 40px;
        }
    }
</style>
</head>
<body>

    <!-- Top Header / Navbar -->
    <header class="top-header">
        <div class="navbar-container">
            <a href="<?php echo e(url('/index')); ?>" class="brand">
                <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Logo2 Entakamala" class="brand-logo2">
                <div class="brand-text">
                    <strong>ENTAKAMALA</strong>
                    <span>Anak &amp; Papua Web</span>
                </div>
            </a>

            <div class="nav-right">
                <nav class="nav-menu" aria-label="Navigasi Utama">
                    <div class="nav-dropdown">
                        <a href="<?php echo e(url('/index')); ?>" class="dropdown-trigger active">Home &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Home/benner-utama')); ?>">benner-utama</a>
                            <a href="<?php echo e(url('/Home/ringkasan-profil')); ?>">ringkasan &amp; profil</a>
                        </div>
                    </div>

                    <div class="nav-dropdown">
                        <a href="#tentang" class="dropdown-trigger">Tentang Kami &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Tentang/profil')); ?>">Profil Entakamala</a>
                            <a href="<?php echo e(url('/Tentang/visi-misi')); ?>">Visi &amp; Misi</a>
                        </div>
                    </div>

                    <div class="nav-dropdown">
                        <a href="#layanan" class="dropdown-trigger">Layanan &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Submenu/pengembangan-web')); ?>">Pengembangan Web</a>
                            <a href="<?php echo e(url('/Submenu/desain-ui-ux')); ?>">Desain UI/UX</a>
                            <a href="<?php echo e(url('/Submenu/konsultasi-digital')); ?>">Konsultasi Digital</a>
                        </div>
                    </div>

                    <div class="nav-dropdown">
                        <a href="#portofolio" class="dropdown-trigger">Portofolio &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Portofolio/sistem-informasi')); ?>">Sistem Informasi Web</a>
                            <a href="<?php echo e(url('/Portofolio/company-profile')); ?>">Company Profile Modern</a>
                        </div>
                    </div>

                    <div class="nav-dropdown">
                        <a href="#blog" class="dropdown-trigger">Blog &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(url('/Blog/html-css')); ?>">Struktur HTML &amp; CSS</a>
                            <a href="<?php echo e(url('/Blog/belajar-laravel')); ?>">Belajar Laravel</a>
                            <a href="<?php echo e(url('/Blog/update-berita')); ?>">Update Berita &amp; Informasi</a>
                        </div>
                    </div>

                    <div class="nav-dropdown">
                        <a href="#kontak" class="dropdown-trigger">Kontak &#9662;</a>
                        <div class="dropdown-menu">
                            <a href="#kontak">Kirim Pesan</a>
                            <a href="https://wa.me/6282199782203" target="_blank" rel="noopener noreferrer">Chat WhatsApp</a>
                        </div>
                    </div>
                </nav>

                <button type="button" class="btn-logout" onclick="logout()">Logout</button>
            </div>
        </div>
    </header>

    <!-- Hero Banner -->
    <section id="home" class="hero-banner">
        <div class="hero-inner">
            <div class="hero-visual">
                <a href="#tentang" class="brand">
                    <img src="<?php echo e(asset('image/halaman .png')); ?>" alt="halaman Entakamala" class="brand-halaman">
                    <div class="brand-text">
                        <strong>ENTAKAMALA</strong>
                        <span>Digital &amp; Personal Web</span>
                    </div>
                </a>
            </div>

            <div class="hero-content">
                <h1>Entakamala </h1>
                <div class="hero-sub">
                    <span class="arrow">&rarr;</span>
                    <span id="userInfo">Selamat datang di website resmi Entakamala</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Konten Utama -->
    <main>
        <section id="Home" class="content-card overlap-card">
            <h2>Home</h2>
            <div class="grid-3">
                <a href="<?php echo e(url('/Home/benner-utama')); ?>" class="item-box" style="text-decoration: none; color: inherit;">
                    <h3>Benner Utama</h3>
                    <p>Menampilkan visual dan informasi penting mengenai layanan digital Entakamala.</p>
                </a>
                <a href="<?php echo e(url('/Home/ringkasan-profil')); ?>" class="item-box" style="text-decoration: none; color: inherit;">
                    <h3>Ringkasan Profil</h3>
                    <p>Profil dan informasi lengkap mengenai visi, misi, serta karya digital yang dikembangkan oleh Entakamala.</p>
                </a>
            </div>
        </section>

        <section id="tentang" class="content-card">
            <h2>Tentang Kami</h2>
            <p>Profil dan informasi lengkap mengenai visi, misi, serta karya digital yang dikembangkan oleh Entakamala.</p>
        </section>

        <section id="layanan" class="content-card">
            <h2>Layanan</h2>
            <div class="grid-3">
                <div class="item-box">
                    <h3>Pengembangan Web</h3>
                    <p>Pembuatan website profil perusahaan, landing page, dan aplikasi berbasis Laravel.</p>
                </div>
                <div class="item-box">
                    <h3>Desain UI/UX</h3>
                    <p>Perancangan antarmuka modern yang bersih, responsif, dan nyaman digunakan.</p>
                </div>
                <div class="item-box">
                    <h3>Konsultasi Digital</h3>
                    <p>Solusi digitalisasi sistem informasi dan optimalisasi performa website.</p>
                </div>
            </div>
        </section>

        <section id="portofolio" class="content-card">
            <h2>Portofolio</h2>
            <div class="grid-3">
                <div class="item-box">
                    <h3>Sistem Informasi Web</h3>
                    <p>Aplikasi manajemen data terintegrasi dengan antarmuka responsif.</p>
                </div>
                <div class="item-box">
                    <h3>Company Profile Modern</h3>
                    <p>Website profil bisnis dengan navigasi cepat dan struktur SEO rapi.</p>
                </div>
            </div>
        </section>

        <section id="blog" class="content-card">
            <h2>Blog</h2>
            <div class="grid-3">
                <article class="item-box">
                    <h3>Memahami Struktur HTML &amp; CSS</h3>
                    <p>Langkah awal membangun tampilan website profesional dari nol.</p>
                </article>
                <article class="item-box">
                    <h3>Mengenal belajar &amp; laravel</h3>
                    <p>Cara menghubungkan antarhalaman menggunakan file Blade dan web.php.</p>
                </article>
                <article class="item-box">
                    <h3>Update Berita &amp; Informasi</h3>
                    <p>Tips menulis konten blog yang menarik dan mudah dibaca pengunjung.</p>
                </article>
            </div>
        </section>

        <section id="kontak" class="content-card">
            <h2>Kontak</h2>
            <p>Silakan kirim pesan jika ingin berdiskusi atau bekerja sama:</p>
            <form class="contact-form" onsubmit="event.preventDefault(); alert('Pesan berhasil dikirim!'); this.reset();">
                <input type="text" placeholder="Nama Lengkap" required>
                <input type="email" placeholder="Alamat Email" required>
                <textarea rows="4" placeholder="Tulis pesan Anda..." required></textarea>
                <button type="submit" class="btn-primary">Kirim Pesan</button>
            </form>
        </section>
    </main>
<!-- Tombol Sosial Media di Bagian Paling Bawah Halaman (Susun ke Kiri) -->
<div class="social-bottom-bar">
    <div class="social-bottom-group" aria-label="Tautan Media Sosial">
        <a href="https://wa.me/6282199782203" target="_blank" rel="noopener noreferrer" class="social-bottom-btn float-wa" title="Hubungi via WhatsApp" aria-label="WhatsApp" data-tooltip="WhatsApp">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.274.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.045.072.045.419-.1.824z"/>
            </svg>
        </a>

        <a href="https://instagram.com/melky___47" target="_blank" rel="noopener noreferrer" class="social-bottom-btn float-ig" title="Instagram" aria-label="Instagram" data-tooltip="Instagram">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M7.75 2h8.5A5.75 5.75 0 0 1 22 7.75v8.5A5.75 5.75 0 0 1 16.25 22h-8.5A5.75 5.75 0 0 1 2 16.25v-8.5A5.75 5.75 0 0 1 7.75 2zm0 1.8A3.95 3.95 0 0 0 3.8 7.75v8.5a3.95 3.95 0 0 0 3.95 3.95h8.5a3.95 3.95 0 0 0 3.95-3.95v-8.5a3.95 3.95 0 0 0-3.95-3.95h-8.5zm8.95 1.35a1.15 1.15 0 1 1 0 2.3 1.15 1.15 0 0 1 0-2.3zM12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10zm0 1.8a3.2 3.2 0 1 0 0 6.4 3.2 3.2 0 0 0 0-6.4z"/>
            </svg>
        </a>

        <a href="https://facebook.com/YameAmoAk" target="_blank" rel="noopener noreferrer" class="social-bottom-btn float-fb" title="Facebook" aria-label="Facebook" data-tooltip="Facebook">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M13.5 22v-8.2h2.75l.41-3.2H13.5V8.56c0-.93.26-1.56 1.59-1.56h1.7V4.14c-.29-.04-1.3-.13-2.48-.13-2.45 0-4.13 1.5-4.13 4.24v2.35H7.4v3.2h2.76V22h3.34z"/>
            </svg>
        </a>

        <a href="https://linkedin.com/in/entakamala" target="_blank" rel="noopener noreferrer" class="social-bottom-btn float-li" title="LinkedIn" aria-label="LinkedIn" data-tooltip="LinkedIn">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="currentColor">
                <path d="M6.94 8.5H3.56V19.5h3.38V8.5zM5.25 3.5a1.97 1.97 0 1 0 0 3.94 1.97 1.97 0 0 0 0-3.94zM20.44 13.02c0-2.76-1.47-4.04-3.44-4.04-1.58 0-2.29.87-2.69 1.48V8.5h-3.38c.04.96 0 11 0 11h3.38v-6.14c0-.33.02-.66.12-.89.27-.66.87-1.34 1.89-1.34 1.33 0 1.86 1.01 1.86 2.5V19.5h3.38v-6.48z"/>
            </svg>
        </a>

        <a href="https://tiktok.com/@entakamala_47" target="_blank" rel="noopener noreferrer" class="social-bottom-btn float-tt" title="TikTok" aria-label="TikTok" data-tooltip="TikTok">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.29 0 .58.04.86.13V9.4a6.33 6.33 0 0 0-.86-.06A6.34 6.34 0 0 0 3.15 15.7a6.34 6.34 0 0 0 10.86 4.43A6.3 6.3 0 0 0 15.86 15.7V8.77a8.26 8.26 0 0 0 4.83 1.55V6.87a4.85 4.85 0 0 1-1.1-.18z"/>
            </svg>
        </a>

        <a href="mailto:kontak@entakamala.com" class="social-bottom-btn float-email" title="Kirim Email" aria-label="Email" data-tooltip="Email">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4-8 5-8-5V6l8 5 8-5v2z"/>
            </svg>
        </a>
    </div>
</div>
    <!-- Tombol & Panel Chat AI ke Admin -->
    <button type="button" class="ai-chat-launcher" onclick="toggleAiChat()" aria-label="Buka Chat AI ke Admin">
        <span>Chat AI Admin</span>
    </button>

    <div id="aiChatPanel" class="ai-chat-panel" role="dialog" aria-label="Chat AI ke Admin">
        <div class="ai-chat-header">
            <div>
                <strong>Asisten AI &amp; Admin Entakamala</strong>
                <span>Tanya layanan, portofolio, atau kirim pesan</span>
            </div>
            <button type="button" class="ai-chat-close" onclick="toggleAiChat()" aria-label="Tutup Chat">&times;</button>
        </div>

        <div id="aiChatMessages" class="ai-chat-messages">
            <div class="chat-msg admin">
                Halo! Ada yang bisa dibantu terkait layanan, portofolio, atau informasi Entakamala? Pesanmu juga bisa diteruskan ke admin.
            </div>
        </div>

        <form id="aiChatForm" class="ai-chat-form">
            <input type="text" id="aiChatInput" placeholder="Tulis pesan untuk AI / Admin..." required>
            <button type="submit" class="ai-chat-send">Kirim</button>
        </form>
    </div>

    <script>
        // Tampilkan sapaan username jika tersedia di localStorage
        const savedUsername = localStorage.getItem('username');
        const userInfoEl = document.getElementById('userInfo');
        if (savedUsername && userInfoEl) {
            userInfoEl.textContent = `Selamat datang, ${savedUsername} — di website resmi Entakamala`;
        }

        // Toggle .nav-dropdown saat diklik di layar kecil (<= 768px)
        const mobileDropdownQuery = window.matchMedia('(max-width: 768px)');
        const dropdownItems = document.querySelectorAll('.nav-dropdown');

        dropdownItems.forEach((dropdown) => {
            const trigger = dropdown.querySelector('.dropdown-trigger');
            if (!trigger) return;

            trigger.addEventListener('click', function (e) {
                if (!mobileDropdownQuery.matches) return;

                e.preventDefault();
                const isAlreadyOpen = dropdown.classList.contains('open');

                // Tutup dropdown lain agar menu tetap rapi
                dropdownItems.forEach((other) => {
                    if (other !== dropdown) {
                        other.classList.remove('open');
                    }
                });

                dropdown.classList.toggle('open', !isAlreadyOpen);
            });
        });

        // Tutup dropdown mobile saat berpindah ke ukuran desktop
        mobileDropdownQuery.addEventListener('change', function (e) {
            if (!e.matches) {
                dropdownItems.forEach((dropdown) => dropdown.classList.remove('open'));
            }
        });

        // Buka / tutup panel chat AI & admin
        function toggleAiChat() {
            const panel = document.getElementById('aiChatPanel');
            if (!panel) return;

            const isOpen = panel.classList.toggle('open');
            if (isOpen) {
                const input = document.getElementById('aiChatInput');
                if (input) input.focus();
            }
        }

        // Kirim pesan pada form chat (placeholder respons lokal; sambungkan ke endpoint backend/AI jika diperlukan)
        const aiChatForm = document.getElementById('aiChatForm');
        const aiChatInput = document.getElementById('aiChatInput');
        const aiChatMessages = document.getElementById('aiChatMessages');

        if (aiChatForm && aiChatInput && aiChatMessages) {
            aiChatForm.addEventListener('submit', function (e) {
                e.preventDefault();
                const text = aiChatInput.value.trim();
                if (!text) return;

                const userBubble = document.createElement('div');
                userBubble.className = 'chat-msg user';
                userBubble.textContent = text;
                aiChatMessages.appendChild(userBubble);

                aiChatInput.value = '';
                aiChatMessages.scrollTop = aiChatMessages.scrollHeight;

                setTimeout(() => {
                    const replyBubble = document.createElement('div');
                    replyBubble.className = 'chat-msg admin';
                    replyBubble.textContent =
                        'Pesan Anda sudah tercatat. Untuk respons cepat dari admin, Anda juga bisa menghubungi WhatsApp kami atau mengisi form Kontak.';
                    aiChatMessages.appendChild(replyBubble);
                    aiChatMessages.scrollTop = aiChatMessages.scrollHeight;
                }, 400);
            });
        }
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\website_saya\resources\views/index.blade.php ENDPATH**/ ?>