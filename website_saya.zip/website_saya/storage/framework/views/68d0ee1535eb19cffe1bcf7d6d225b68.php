<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Benner Utama - Entakamala</title>
    <script>
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            window.location.href = '/';
        }

        function logout() {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    </script>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f6f9;
            color: #1e293b;
            line-height: 1.7;
        }

        /* Header */
        .top-header {
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
            padding: 12px 24px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-inner {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #0f172a;
        }

        .brand img {
            width: 42px;
            height: 42px;
            object-fit: contain;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-text strong {
            font-size: 1rem;
            letter-spacing: 0.5px;
            color: #0f172a;
        }

        .brand-text span {
            font-size: 0.75rem;
            color: #64748b;
        }

        .btn-logout {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            background: #ef4444;
            color: #ffffff;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .btn-logout:hover {
            background: #dc2626;
        }

        /* Konten Banner */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 36px 24px;
        }

        .banner-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 28px;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.05);
            margin-bottom: 24px;
        }

        .banner-photo-box {
            width: 100%;
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid #e2e8f0;
            background: #f8fafc;
            margin-bottom: 24px;
        }

        .banner-photo {
            width: 100%;
            max-height: 460px;
            object-fit: cover;
            display: block;
        }

        .banner-caption h1 {
            font-size: 1.75rem;
            color: #0f172a;
            margin-bottom: 8px;
        }

        .banner-caption p {
            color: #475569;
            font-size: 15px;
            margin-bottom: 20px;
        }

        .btn-back {
            display: inline-block;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            background: #2563eb;
            color: #ffffff;
            font-size: 0.95rem;
            font-weight: 500;
            transition: background-color 0.2s;
        }

        .btn-back:hover {
            background: #1d4ed8;
        }
    </style>
</head>
<body>

    <header class="top-header">
        <div class="header-inner">
            <a href="<?php echo e(url('/index')); ?>" class="brand">
                <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Logo Entakamala">
                <div class="brand-text">
                    <strong>ENTAKAMALA</strong>
                    <span>Digital &amp; Personal Web</span>
                </div>
            </a>

            <button type="button" class="btn-logout" onclick="logout()">Logout</button>
        </div>
    </header>

    <section id="benner-utama">
        <div class="container">
            <div class="banner-card">
                <div class="banner-photo-box">
                    <img src="<?php echo e(asset('image/halaman .png')); ?>" alt="Foto Banner Utama" class="banner-photo">
                </div>

                <div class="banner-caption">
                    <h1>Selamat Datang di Website Saya</h1>
                    <p>Ini adalah halaman utama dengan banner yang menarik.</p>
                    <a href="<?php echo e(url('/index')); ?>" class="btn-back">&larr; Kembali ke Beranda</a>
                </div>
            </div>
        </div>
    </section>

</body>
</html>
<?php /**PATH C:\laragon\www\website_saya\resources\views/Halaman/Home/benner-utama.blade.php ENDPATH**/ ?>