<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Desain UI/UX - Entakamala</title>
    <script>
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            window.location.href = '/';
        }
    </script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f6f9;
            color: #1e293b;
            line-height: 1.6;
        }

        /* Header & Navbar */
        .top-header {
            background-color: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .navbar-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
        }

        /* Brand & Logo Kecil di Navbar */
        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #0f172a;
        }

        .brand-logo2 {
            width: 42px;
            height: 42px;
            object-fit: contain;
            border-radius: 8px;
            flex-shrink: 0;
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-text strong {
            font-size: 1rem;
            letter-spacing: 0.5px;
            color: #0f172a;
        }

        .brand-text span {
            font-size: 0.75rem;
            color: #64748b;
        }

        /* Tombol Logout */
        .btn-logout {
            background-color: #ef4444;
            color: #ffffff;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .btn-logout:hover {
            background-color: #dc2626;
        }

        /* Konten Utama */
        .main-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 36px 24px;
        }

        .content-card {
            background-color: #ffffff;
            padding: 36px;
            border-radius: 14px;
            box-shadow: 0 6px 20px rgba(15, 23, 42, 0.06);
        }

        /* Foto di Kiri, Teks di Kanan */
        .card-grid {
            display: grid;
            grid-template-columns: 0.85fr 1.15fr;
            gap: 32px;
            align-items: center;
        }

        .card-media {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .uiux-photo {
            width: 100%;
            max-width: 240px;
            max-height: 280px;
            object-fit: contain;
            display: block;
        }

        .badge {
            display: inline-block;
            background-color: #eff6ff;
            color: #2563eb;
            font-size: 0.8rem;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 999px;
            margin-bottom: 12px;
        }

        .card-text h2 {
            font-size: 1.75rem;
            color: #0f172a;
            margin-bottom: 12px;
        }

        .card-text p {
            color: #475569;
            margin-bottom: 24px;
        }

        .btn-primary.btn-back {
            display: inline-block;
            background-color: #2563eb;
            color: #ffffff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.95rem;
            transition: background-color 0.2s;
        }

        .btn-primary.btn-back:hover {
            background-color: #1d4ed8;
        }

        /* Responsif Mobile */
        @media (max-width: 768px) {
            .card-grid {
                grid-template-columns: 1fr;
            }

            .content-card {
                padding: 24px;
            }
        }
    </style>
</head>
<body>
    <header class="top-header">
        <div class="navbar-container">
            <a href="<?php echo e(url('/beranda')); ?>" class="brand">
                <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Logo Entakamala" class="brand-logo2">
                <div class="brand-text">
                    <strong>ENTAKAMALA</strong>
                    <span>Digital &amp; Personal Web</span>
                </div>
            </a>

            <button type="button" class="btn-logout" onclick="logout()">Logout</button>
        </div>
    </header>

    <main class="main-content">
        <section class="content-card">
            <div class="card-grid">
                <div class="card-media">
                    <img src="<?php echo e(asset('image/logo2.png')); ?>" alt="Ilustrasi Desain UI/UX Entakamala" class="uiux-photo">
                </div>

                <div class="card-text">
                    <span class="badge">Layanan Kami</span>
                    <h2>Desain UI/UX</h2>
                    <p>
                        Perancangan antarmuka (User Interface) dan pengalaman pengguna (User Experience)
                        yang modern, terstruktur, mudah dipahami, dan nyaman digunakan di layar desktop
                        maupun mobile.
                    </p>
                    <a href="<?php echo e(url('/beranda')); ?>" class="btn-primary btn-back">&larr; Kembali ke Beranda</a>
                </div>
            </div>
        </section>
    </main>

    <script>
        function logout() {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\website_saya\resources\views/Halaman/Submenu/desain-ui-ux.blade.php ENDPATH**/ ?>