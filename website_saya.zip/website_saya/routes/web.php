<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('login');
});

Route::get('/index', function () {
    return view('index');
});

Route::get('/beranda', function () {
    return view('index');
});

Route::get('/Home/benner-utama', function () {
    return view('Halaman.Home.benner-utama');
});

Route::get('/Home/ringkasan-profil', function () {
    return view('Halaman.Home.ringkasan-profil');
});

// Halaman khusus per submenu
Route::get('/Submenu/pengembangan-web', function () {
    return view('Halaman.Submenu.pengembangan-web');
});

Route::get('/Submenu/desain-ui-ux', function () {
    return view('Halaman.Submenu.desain-ui-ux');
});

Route::get('/Submenu/konsultasi-digital', function () {
    return view('Halaman.Submenu.konsultasi-digital');
});

Route::get('/Tentang/profil', function () {
    return view('Halaman.Tentang.profil');
});

Route::get('/Tentang/visi-misi', function () {
    return view('Halaman.Tentang.visi-misi');
});

Route::get('/Portofolio/sistem-informasi', function () {
    return view('Halaman.Portofolio.sistem-informasi');
});

Route::get('/Portofolio/company-profile', function () {
    return view('Halaman.Portofolio.company-profile');
});

Route::get('/Blog/html-css', function () {
    return view('Halaman.Blog.html-css');
});

Route::get('/Blog/belajar-laravel', function () {
    return view('Halaman.Blog.belajar-laravel');
});

Route::get('/Blog/update-berita', function () {
    return view('Halaman.Blog.update-berita');
});
